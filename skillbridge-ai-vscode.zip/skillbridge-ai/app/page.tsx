 "use client";

import { useMemo, useState } from "react";
import {
  ArrowRight, BarChart3, BriefcaseBusiness, CheckCircle2, ChevronRight,
  CircleUserRound, ClipboardList, FileText, GraduationCap, LayoutDashboard,
  LogOut, Menu, Search, Sparkles, Target, TrendingUp, UploadCloud, X
} from "lucide-react";

type Project = {
  id: number; title: string; company: string; category: string;
  level: string; duration: string; description: string; skills: string[];
  color: string;
};

const projects: Project[] = [
  {
    id: 1, title: "Sales Performance Analysis", company: "RetailLab (демо-кейс)",
    category: "Data Analytics", level: "Начальный", duration: "2–3 дня",
    description: "Проанализируйте данные о продажах магазина за три месяца. Найдите причины снижения выручки и предложите решения.",
    skills: ["Excel", "Анализ данных", "Бизнес-мышление"], color: "blue"
  },
  {
    id: 2, title: "Customer Retention Strategy", company: "GrowthWorks (демо-кейс)",
    category: "Business", level: "Средний", duration: "3–4 дня",
    description: "Изучите поведение клиентов и предложите план повышения повторных покупок.",
    skills: ["Исследование", "Стратегия", "Презентация"], color: "purple"
  },
  {
    id: 3, title: "Market Entry Research", company: "Qazaq Market (демо-кейс)",
    category: "Economics", level: "Средний", duration: "4 дня",
    description: "Оцените потенциал нового продукта на локальном рынке и подготовьте краткий анализ.",
    skills: ["Экономика", "Исследование рынка", "Аналитика"], color: "orange"
  }
];

type Assessment = { total: number; scores: number[]; feedback: string[] };

export default function Home() {
  const [active, setActive] = useState("overview");
  const [selected, setSelected] = useState<Project | null>(null);
  const [submission, setSubmission] = useState("");
  const [assessment, setAssessment] = useState<Assessment | null>(null);
  const [query, setQuery] = useState("");
  const [mobileMenu, setMobileMenu] = useState(false);
  const [completed, setCompleted] = useState<number[]>([]);

  const filtered = useMemo(() => projects.filter(p =>
    `${p.title} ${p.category} ${p.skills.join(" ")}`.toLowerCase().includes(query.toLowerCase())
  ), [query]);

  function runDemoAssessment() {
    if (submission.trim().length < 25) {
      alert("Добавьте более подробное решение (минимум 25 символов), чтобы запустить демо-оценку.");
      return;
    }
    // Это демонстрационная оценка на стороне браузера, а не настоящая AI-модель.
    const words = submission.trim().split(/\s+/).length;
    const scores = [
      Math.min(30, Math.round(12 + words / 5)),
      Math.min(25, Math.round(10 + words / 7)),
      Math.min(25, Math.round(10 + words / 8)),
      Math.min(20, Math.round(8 + words / 10))
    ];
    const total = scores.reduce((a, b) => a + b, 0);
    setAssessment({
      total,
      scores,
      feedback: [
        "Вы сформулировали исходную проблему. Усильте работу точными цифрами и сравнением периодов.",
        "Добавьте причинно-следственную связь: покажите, какие показатели подтверждают ваш вывод.",
        "Превратите рекомендации в конкретный план: действие, срок, ожидаемый результат и метрика.",
      ]
    });
    if (selected && !completed.includes(selected.id)) setCompleted([...completed, selected.id]);
  }

  const nav = [
    { id: "overview", label: "Обзор", icon: LayoutDashboard },
    { id: "projects", label: "Практические проекты", icon: ClipboardList },
    { id: "portfolio", label: "Моё портфолио", icon: BriefcaseBusiness },
  ];

  return (
    <main className="app-shell">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="brand">
          <div className="brand-mark"><Sparkles size={21} /></div>
          <div><strong>skillbridge<span>ai</span></strong><small>CAREER • SKILLS • PROOF</small></div>
          <button className="close-menu" onClick={() => setMobileMenu(false)} aria-label="Закрыть меню"><X size={19}/></button>
        </div>
        <div className="workspace-label">РАБОЧЕЕ ПРОСТРАНСТВО</div>
        <nav>
          {nav.map(item => {
            const Icon = item.icon;
            return <button key={item.id} className={`nav-item ${active === item.id ? "active" : ""}`}
              onClick={() => { setActive(item.id); setSelected(null); setAssessment(null); setMobileMenu(false); }}>
              <Icon size={18}/><span>{item.label}</span>{item.id === "portfolio" && <span className="nav-count">{completed.length}</span>}
            </button>;
          })}
        </nav>
        <div className="sidebar-bottom">
          <div className="help-card">
            <div className="help-icon"><GraduationCap size={18}/></div>
            <strong>Построй карьеру на практике</strong>
            <p>Каждый проект — новое доказательство твоих навыков.</p>
          </div>
          <div className="profile-mini">
            <div className="avatar">S</div>
            <div><strong>Student Demo</strong><small>Студенческий аккаунт</small></div>
            <LogOut size={16} className="logout"/>
          </div>
        </div>
      </aside>

      <section className="main-area">
        <header className="topbar">
          <button className="mobile-menu" onClick={() => setMobileMenu(true)} aria-label="Открыть меню"><Menu/></button>
          <div className="breadcrumb">Рабочее пространство <ChevronRight size={15}/> <b>{nav.find(n => n.id === active)?.label ?? "Проект"}</b></div>
          <div className="top-actions"><span className="status-dot"/> Demo environment <div className="top-avatar">S</div></div>
        </header>

        <div className="content">
          {selected ? (
            <ProjectDetail project={selected} submission={submission} setSubmission={setSubmission}
              assessment={assessment} runAssessment={runDemoAssessment} onBack={() => {setSelected(null); setAssessment(null);}} />
          ) : active === "overview" ? (
            <>
              <div className="welcome-row">
                <div><div className="eyebrow">ПЯТНИЦА, 6 НОЯБРЯ 2026</div><h1>Привет, Student <span>👋</span></h1>
                  <p className="muted">Превращай знания в реальные доказательства навыков.</p></div>
                <button className="primary-btn" onClick={() => setActive("projects")}>Найти проект <ArrowRight size={17}/></button>
              </div>
              <div className="hero-card">
                <div className="hero-copy"><div className="hero-tag"><Sparkles size={14}/> YOUR NEXT CAREER STEP</div>
                  <h2>Опыт начинается<br/>не после найма.</h2>
                  <p>Решай практические бизнес-задачи, получай структурированную обратную связь и собирай портфолио, которое можно показать работодателю.</p>
                  <button className="hero-btn" onClick={() => setActive("projects")}>Посмотреть задания <ArrowRight size={16}/></button>
                </div>
                <div className="hero-visual">
                  <div className="orbit orbit-one"/><div className="orbit orbit-two"/>
                  <div className="visual-card"><div className="visual-card-top"><span>SKILL REPORT</span><CheckCircle2 size={17}/></div>
                    <div className="visual-score">86<span>/100</span></div><div className="visual-line"><i/></div>
                    <div className="visual-bars"><i/><i/><i/><i/></div><small>SKILLS VERIFIED · DEMO</small></div>
                  <div className="float-chip chip-a"><TrendingUp size={15}/> Skill growth</div>
                  <div className="float-chip chip-b"><CheckCircle2 size={15}/> Project completed</div>
                </div>
              </div>
              <div className="section-heading"><div><h2>Твой прогресс</h2><p>Показатели твоего профессионального развития</p></div></div>
              <div className="stats-grid">
                <Stat icon={<ClipboardList/>} label="Доступные проекты" value="03" note="Практические задания"/>
                <Stat icon={<CheckCircle2/>} label="Завершено" value={String(completed.length).padStart(2,"0")} note="Проекты в портфолио"/>
                <Stat icon={<Target/>} label="Подтверждённые навыки" value={String(completed.length * 3).padStart(2,"0")} note="Демо-показатель"/>
                <Stat icon={<BarChart3/>} label="Средний результат" value={assessment ? `${assessment.total}` : "—"} note="Баллы из 100"/>
              </div>
              <div className="section-heading projects-heading"><div><h2>Рекомендуемые проекты</h2><p>Начни с практической задачи по аналитике</p></div>
                <button className="text-btn" onClick={() => setActive("projects")}>Все проекты <ArrowRight size={15}/></button></div>
              <div className="project-grid">
                {projects.slice(0,2).map(p => <ProjectCard key={p.id} project={p} onOpen={() => {setSelected(p); setSubmission(""); setAssessment(null);}} />)}
              </div>
              <div className="notice"><Sparkles size={17}/><span><b>Важно:</b> задания и оценки в этой версии — демонстрационные. Для пилота подключите реальные компании и серверную AI-оценку.</span></div>
            </>
          ) : active === "projects" ? (
            <>
              <div className="page-title"><div className="eyebrow">LEARN BY DOING</div><h1>Практические проекты</h1><p className="muted">Решай задачи, похожие на реальные запросы бизнеса.</p></div>
              <div className="search-box"><Search size={18}/><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Поиск по названию, категории или навыку..."/></div>
              <div className="project-grid">
                {filtered.map(p => <ProjectCard key={p.id} project={p} onOpen={() => {setSelected(p); setSubmission(""); setAssessment(null);}} />)}
              </div>
              {filtered.length === 0 && <div className="empty-state">Проекты не найдены. Попробуй изменить запрос.</div>}
            </>
          ) : (
            <>
              <div className="page-title"><div className="eyebrow">YOUR PROOF OF WORK</div><h1>Моё портфолио</h1><p className="muted">Завершённые проекты и результаты твоей работы.</p></div>
              {completed.length === 0 ? <div className="empty-state"><div className="empty-icon"><FileText/></div><h3>Пока нет завершённых проектов</h3><p>Выбери практическое задание и отправь своё решение. После оценки оно появится здесь.</p><button className="primary-btn" onClick={() => setActive("projects")}>Найти первый проект <ArrowRight size={16}/></button></div> :
                <div className="portfolio-list">{projects.filter(p => completed.includes(p.id)).map(p => <div className="portfolio-item" key={p.id}><div className="portfolio-icon"><CheckCircle2/></div><div className="portfolio-info"><b>{p.title}</b><span>{p.company} · {p.category}</span></div><span className="completed-label">Завершено</span></div>)}</div>}
            </>
          )}
        </div>
      </section>
    </main>
  );
}

function Stat({icon,label,value,note}:{icon:React.ReactNode;label:string;value:string;note:string}) {
  return <div className="stat-card"><div className="stat-top"><span>{label}</span><div className="stat-icon">{icon}</div></div><strong>{value}</strong><small>{note}</small></div>;
}

function ProjectCard({project,onOpen}:{project:Project;onOpen:()=>void}) {
  return <article className="project-card"><div className="project-card-top"><div className={`project-icon ${project.color}`}><BarChart3 size={20}/></div><span className="level-pill">{project.level}</span></div>
    <div className="project-category">{project.category}</div><h3>{project.title}</h3><div className="company-name"><BriefcaseBusiness size={14}/>{project.company}</div>
    <p>{project.description}</p><div className="skill-tags">{project.skills.map(s=><span key={s}>{s}</span>)}</div>
    <div className="project-card-footer"><span>{project.duration}</span><button onClick={onOpen}>Открыть проект <ArrowRight size={15}/></button></div>
  </article>;
}

function ProjectDetail({project,submission,setSubmission,assessment,runAssessment,onBack}:{
  project:Project; submission:string; setSubmission:(v:string)=>void; assessment:Assessment|null;
  runAssessment:()=>void; onBack:()=>void;
}) {
  return <div className="detail-wrap"><button className="back-btn" onClick={onBack}>← Все проекты</button>
    <div className="page-title"><div className="eyebrow">{project.category.toUpperCase()} · {project.level.toUpperCase()}</div><h1>{project.title}</h1><p className="muted">{project.company} · {project.duration}</p></div>
    <div className="detail-layout"><div className="detail-main">
      <section className="panel"><h2>Описание задания</h2><p>{project.description}</p><div className="task-brief"><b>Что нужно сделать</b><ol><li>Изучить исходные данные и определить ключевые тенденции.</li><li>Сформулировать возможные причины наблюдаемой проблемы.</li><li>Предложить три конкретные рекомендации для бизнеса.</li><li>Обосновать выводы цифрами и логикой.</li></ol></div></section>
      <section className="panel"><h2>Отправить решение</h2><p className="muted small">Опиши ход анализа, выводы и рекомендации. В этой демо-версии загрузка файлов пока не подключена.</p>
        <textarea value={submission} onChange={e=>setSubmission(e.target.value)} placeholder="1. Основные наблюдения...&#10;2. Возможные причины...&#10;3. Мои рекомендации..."/>
        <div className="submit-row"><span>{submission.length} символов</span><button className="primary-btn" onClick={runAssessment}><Sparkles size={16}/> Оценить решение</button></div>
      </section>
      {assessment && <section className="panel result-panel"><div className="result-header"><div><div className="eyebrow">DEMO AI ASSESSMENT</div><h2>Результат оценки</h2></div><div className="result-score">{assessment.total}<small>/100</small></div></div>
        <div className="rubric">{["Анализ данных","Логика выводов","Практические решения","Презентация"].map((label,i)=><div className="rubric-row" key={label}><div><span>{label}</span><b>{assessment.scores[i]} / {[30,25,25,20][i]}</b></div><div className="progress-track"><i style={{width:`${assessment.scores[i]/[30,25,25,20][i]*100}%`}}/></div></div>)}</div>
        <h3>Рекомендации для улучшения</h3><ul className="feedback-list">{assessment.feedback.map(f=><li key={f}>{f}</li>)}</ul>
        <div className="demo-warning">Это демонстрационная оценка по длине ответа, а не анализ содержания нейросетью. Не используйте её как реальную оценку навыков.</div>
      </section>}
    </div><aside className="detail-side"><div className="panel"><h3>Навыки проекта</h3><div className="side-tags">{project.skills.map(s=><span key={s}>{s}</span>)}</div><div className="side-divider"/><div className="side-meta"><span>Уровень</span><b>{project.level}</b></div><div className="side-meta"><span>Срок</span><b>{project.duration}</b></div><div className="side-meta"><span>Формат</span><b>Практический кейс</b></div></div><div className="side-tip"><Sparkles size={18}/><b>Совет</b><p>Используй конкретные данные, объясняй логику и связывай каждую рекомендацию с измеримым результатом.</p></div></aside></div>
  </div>;
}
